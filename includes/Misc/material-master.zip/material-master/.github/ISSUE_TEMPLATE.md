**Actual Behavior**:
 -  `What is the issue? *`
 -  `What is the expected behavior?`

**CodePen** (or steps to reproduce the issue): *
 -  `CodePen Demo which shows your issue:`
 -  `Details:`

**AngularJS Versions**: *
 -  `AngularJS Version:`
 -  `AngularJS Material Version:`

**Additional Information**:
 -  `Browser Type: *`
 -  `Browser Version: *`
 -  `OS: *`
 -  `Stack Traces:`

----
Shortcut to create a [new CodePen Demo](http://codepen.io/team/AngularMaterial/pen/bEGJdd).
Note: `*` indicates required information. Without this information, your issue may be auto-closed.

> Do not modify the titles or questions. Simply add your responses to the ends of the questions.
  Add more lines if needed.